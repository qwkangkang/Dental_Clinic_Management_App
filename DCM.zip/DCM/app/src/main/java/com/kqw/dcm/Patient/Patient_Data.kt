package com.kqw.dcm.Patient

data class Patient_Data(val patientID:String, val patientName: String, val gender: String, val age: Int, val contactNo: String) {

}