package com.kqw.dcm.FAQ

data class FAQ_Data(val faqID:String, val faqQues:String, val faqAns:String){

}
