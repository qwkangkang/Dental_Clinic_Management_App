package com.kqw.dcm.Consultation

data class Consultation_Data(val conID:String, val conQues:String, val conDate:String, val conTime:String, val conStatus:String){

}
