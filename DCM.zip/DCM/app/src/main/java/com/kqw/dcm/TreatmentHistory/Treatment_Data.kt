package com.kqw.dcm.TreatmentHistory

//data class Treatment_Data(val treatmentID:String, val patientID:String, val doctorName:String, val treatmentName:String, val treatmentDate:String, val treatmentTime:String, val treatmentPatientID:String, val treatment_remark:String, val treatmentPrescription:String, val treatmentDetail:String){
data class Treatment_Data(val treatmentID:String, val patientID:String, val doctorName:String, val treatmentName:String, val treatmentDate:String, val treatmentTime:String,  val treatment_remark:String, val treatmentPrescription:String, val treatmentDetail:String){

}
