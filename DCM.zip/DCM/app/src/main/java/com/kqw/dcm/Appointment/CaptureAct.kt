package com.kqw.dcm.Appointment

import com.journeyapps.barcodescanner.CaptureActivity

class CaptureAct: CaptureActivity() {

}
